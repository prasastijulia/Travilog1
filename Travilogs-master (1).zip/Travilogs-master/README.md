# Travilogs

Clone this project

Follow command :

1. `yarn` or `npm install`
2. `react-native link`
3. `react-native run-android`
